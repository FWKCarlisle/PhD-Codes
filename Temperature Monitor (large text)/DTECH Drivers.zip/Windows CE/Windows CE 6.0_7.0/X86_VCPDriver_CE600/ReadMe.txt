
========================================================================
      Windows Embedded Compact/CE Component : FTDI_VCP_x86_CE600
========================================================================


CEComponentWiz has created this FTDI_VCP_x86_CE600 component for you.  

This file contains a summary of what you will find in each of the files that
make up your FTDI_VCP_x86_CE600 component.

FTDI_VCP_x86_CE600.pbpxml
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. 
    
.\Catalog\FTDI_VCP_x86_CE600.pbpcxml
    This is a catalog file for the project. 
    
.\Resources
Contains the files to be included in the image and requested shortcut files 
